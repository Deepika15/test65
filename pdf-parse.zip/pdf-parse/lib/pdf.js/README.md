# check https://mozilla.github.io/pdf.js/getting_started/#download 
# just download then delete web folder and license file
